<html>
    <head>
        <title>Web</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>


      <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3>Insert Book Details</h3><hr>
                    <form id="frm" method="post" action="{{ url('save') }}">
                        @csrf
                        <div class="form-group">
                            <label for="">Name :</label>
                            <input type="text" class="form-control" id="name" name="name">
                        </div>
                        <div class="form-group">
                            <label for="">Author :</label>
                            <input type="text" class="form-control" id="author" name="author">
                        </div>
                        <div class="form-group">
                            <label for="">Price :</label>
                            <input type="text" class="form-control" id="price" name="price">
                        </div>
                        <div class="form-group"  align="right">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        {{-- display data --}}
        <div class="row">
            <div class="col-md-12">
                <h2>Book Listing</h2>
                <table class="table table-responsive" style="width: 200px">
                    <tr>
                        <th>Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                    @foreach ($data as $books)
                        <tr>
                            <td>
                                {{$books->name}}
                            </td>
                            <td>
                                {{$books->author}}
                            </td>
                            <td>
                                {{$books->price}}
                            </td>
                            <td>
                            <a href="#">Delete</a>
                            </td>
                        </tr>
                    @endforeach
                </table>
            </div>
        </div>
        {{-- display data --}}

        </div>


        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
        {{-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
            $(document).ready(function(){

                $('#frm').on('submit',function(e){
                    e.preventDefault();
                    // alert("s");
                    var name = $('#name').val();
                    var author = $('#author').val();
                    var price = $('#price').val();
                    $.ajax({
                        url: "{{ url('save') }}",
                        type: "POST",
                        data: {
                            "_token": "{{ csrf_token() }}",
                            name : name,
                            author : author,
                            price : price
                        },
                        success: function(result){
                            alert("Data Is Successfully Inserted");
                        }
                    });
                });
                $('#myModal').on('shown.bs.modal', function () {
                $('#myInput').trigger('focus')
            });

            });
        </script> --}}

    </body>
</html>
