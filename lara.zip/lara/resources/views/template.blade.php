<html>
    <head>
        <title>@yield('Title')</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            @section('header')
                <div class="row">
                    <div class="col-md-12 bg-dark">
                        <h1 class="text-light">BOOK MANAGEMENT SYSTEM</h1>
                    </div>
                </div>
            @show

            @section('menus')
                <div class="row" align="center">
                    <div class="col-md-4">
                        <a href="">HOME</a>
                    </div>
                    <div class="col-md-4">
                        <a href="">INSERT</a>
                    </div>
                    <div class="col-md-4">
                        <a href="">LISTING</a>
                    </div>
                </div>
            @show

            @yield('content')

            @section('footer')
                <div class="row bg-dark">
                    <div class="col-md-12">
                        <h2 class="text-light">This is footer</h2>
                    </div>
                </div>
            @show
        </div>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

        @yield('scripts')

    </body>
</html>
