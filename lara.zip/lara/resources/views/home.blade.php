@extends('template')

@section('title','Home')

@section('header')
    @parent
@endsection

@section('content')
    <div class="row">
        <div class="col-md-12">
            <h3>THIS IS HOME</h3>
        </div>
    </div>
@endsection

@section('footer')
    @parent
@endsection
