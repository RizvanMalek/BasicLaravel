<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;

class BookController extends Controller
{
    public function index()
    {
        return route("insert");
    }
    public function insert()
    {
        $data = Book::all();
        return view('insert',['data' => $data]);
    }
    public function save(Request $request)
    {
        $book = new Book;
        $book->name = $request->input('name');
        $book->author = $request->input('author');
        $book->price = $request->input('price');
        $book->save();
        return redirect('insert');
    }
}
