<html>
    <head>
        <title><?php echo $__env->yieldContent('Title'); ?></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <?php $__env->startSection('header'); ?>
                <div class="row">
                    <div class="col-md-12 bg-dark">
                        <h1 class="text-light">BOOK MANAGEMENT SYSTEM</h1>
                    </div>
                </div>
            <?php echo $__env->yieldSection(); ?>

            <?php $__env->startSection('menus'); ?>
                <div class="row" align="center">
                    <div class="col-md-4">
                        <a href="">HOME</a>
                    </div>
                    <div class="col-md-4">
                        <a href="">INSERT</a>
                    </div>
                    <div class="col-md-4">
                        <a href="">LISTING</a>
                    </div>
                </div>
            <?php echo $__env->yieldSection(); ?>

            <?php echo $__env->yieldContent('content'); ?>

            <?php $__env->startSection('footer'); ?>
                <div class="row bg-dark">
                    <div class="col-md-12">
                        <h2 class="text-light">This is footer</h2>
                    </div>
                </div>
            <?php echo $__env->yieldSection(); ?>
        </div>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

        <?php echo $__env->yieldContent('scripts'); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\lara\resources\views/template.blade.php ENDPATH**/ ?>