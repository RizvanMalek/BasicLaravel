<html>
    <head>
        <title>Web</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>


      <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3>Insert Book Details</h3><hr>
                    <form id="frm" method="post" action="<?php echo e(url('save')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Name :</label>
                            <input type="text" class="form-control" id="name" name="name">
                        </div>
                        <div class="form-group">
                            <label for="">Author :</label>
                            <input type="text" class="form-control" id="author" name="author">
                        </div>
                        <div class="form-group">
                            <label for="">Price :</label>
                            <input type="text" class="form-control" id="price" name="price">
                        </div>
                        <div class="form-group"  align="right">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        
        <div class="row">
            <div class="col-md-12">
                <h2>Book Listing</h2>
                <table class="table table-responsive" style="width: 200px">
                    <tr>
                        <th>Name</th>
                        <th>Author</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $books): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($books->name); ?>

                            </td>
                            <td>
                                <?php echo e($books->author); ?>

                            </td>
                            <td>
                                <?php echo e($books->price); ?>

                            </td>
                            <td>
                            <a href="#">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        

        </div>


        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
        

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\lara\resources\views/insert.blade.php ENDPATH**/ ?>